package mini_project;
import java.util.Scanner;

public class Bank_loan {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Input Section
        System.out.print("Enter Monthly Income (₹): ");
        double income = sc.nextDouble();

        System.out.print("Enter Age: ");
        int age = sc.nextInt();

        System.out.print("Enter Credit Score: ");
        int creditScore = sc.nextInt();

        // Eligibility Check
        if (income >= 25000 && age >= 21 && age <= 60 && creditScore >= 650) {

            System.out.println("\n Loan Eligibility Result: ELIGIBLE");

            // Max Loan Amount (example: 20 times monthly income)
            double maxLoanAmount = income * 20;
            System.out.println(" Maximum Loan Amount: ₹" + maxLoanAmount);

            // EMI Calculation
            System.out.print("\nEnter Loan Tenure (in years): ");
            int years = sc.nextInt();

            System.out.print("Enter Annual Interest Rate (%): ");
            double annualRate = sc.nextDouble();

            double monthlyRate = annualRate / (12 * 100);
            int months = years * 12;

            double emi = (maxLoanAmount * monthlyRate * Math.pow(1 + monthlyRate, months))
                    / (Math.pow(1 + monthlyRate, months) - 1);

            System.out.println(" Monthly EMI: ₹" + String.format("%.2f", emi));

        } else {
            System.out.println("\n Loan Eligibility Result: NOT ELIGIBLE");
        }

        sc.close();
    }
}

	 


