package Number_based;

public class Program13 {

	public static void main(String[] args) {
		int num1 = 123; // Sample Input
        int num2 = 456;

        // The simplest way: String concatenation
        String combined = String.valueOf(num1) + String.valueOf(num2);

        System.out.println(combined);

	}

}
