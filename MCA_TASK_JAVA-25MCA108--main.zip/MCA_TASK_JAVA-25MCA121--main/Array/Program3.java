package Array;
import java.util.Arrays;
public class Program3 {

	public static void main(String[] args) {
       int[] arr = {5, 3, 2, 4};
        
        Arrays.sort(arr);
        
        System.out.println(Arrays.toString(arr));
	}

}
